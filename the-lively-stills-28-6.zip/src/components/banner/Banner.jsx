import React from 'react'
import './Banner.css'
export function Banner(){
    return (
    
    <div className="otherframe">
        <div className="line1">
        </div>
        <div className="line2">
        </div>
        <div className="filmtitle"> 
             <div className="f">A</div>
             <div className="midfilmtitle">FILM</div>
             <div className="l">CORNER</div>
        </div>
        <div className="lasttwo">
        <div className="line3">
        </div>
        <div className="line4">
        </div>
        </div>
    </div>
    
    
    
        )
}