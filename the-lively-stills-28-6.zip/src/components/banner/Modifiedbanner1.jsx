import React from 'react'
import './Modifiedbanner.css'
export function Modifiedbanner1(){
    return (
    <div className="otherframe">
        <div className="line1">
        </div>
        <div className="line2">
        </div>
        <div className="filmtitle1"> BOOKS
        </div>
        <div className="lasttwo1">
        <div className="line3">
        </div>
        <div className="line4">
        </div>
        </div>
    </div>
    )
}