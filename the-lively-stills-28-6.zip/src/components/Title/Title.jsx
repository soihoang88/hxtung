
import React from 'react'
import './Title.css'
export function Title(){
    return (
        <div className="background">
            <div className="main">The Lively </div>
            <div className="main2"> Stills</div>
            <div className="side">A Film Corner</div>
        </div>
    )
}