import React from 'react'
import './aboutframe.css'
export function Aboutframe(){
  return(
    <div className="thewholething"> 
        <div className="theframe">
           <div className="ftc">
              From The Creator
           </div>
           <div className="dots">
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
               <div className="dot"></div>
           </div>
           <div className="introtext1">
           Hello there dear visitors! </div>
        <div className="introtext2">
Welcome to my personal blog, "The lively stills", where i post my writings of all sorts from poems, short stories to film reviews and anatomies - all under the pen name "Anton Vega". Follow the website if you find anything helpful or simply intriguing. I'll regularly post once or twice every two weeks, so stay tuned!

           </div>
           <div className="introtext3">
           --- Tung Hoang --- 
           </div>
        </div>
    </div>
  )
}